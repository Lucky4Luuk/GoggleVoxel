local mesh = require "modules.mesh"

describe("mesh:", function()
end)

--[[
average(vertices)
normal(triangle)
plane_from_triangle(triangle)
is_front_facing(plane, direction)
signed_distance(point, plane)
--]]