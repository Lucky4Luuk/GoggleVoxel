local l3d = require("love3d")
l3d.import(true)

local cpml = require "cpml"

local camx = 0
local camy = 0.1
local camz = 0

local camlookx = 0
local camlooky = 0
local camlookz = 0

local camrot = cpml.vec3()
local sensitivity = 15

local chunks = {}
local chunkmeshes = {}

function generateChunks()
	local c = {}
	for cx=0,cx<16 do
		for cy=0,cy<16 do
			local chunk = {}
			for x=0,x<16 do
				table.insert(chunk,{})
				for y=0,y<16 do
					table.insert(chunk[x],{})
					for z=0,z<16 do
						table.insert(chunk[x][y],1)
					end
				end
			end
			table.insert(c,chunk)
		end
	end
	
	return c
end

function generateChunkMeshes(c)
	for cx=0,cx<16 do
		for cy=0,cy<16 do
			local chunk = {}
			for x=0,x<16 do
				table.insert(chunk,{})
				for y=0,y<16 do
					table.insert(chunk[x],{})
					for z=0,z<16 do
						table.insert(chunk[x][y],1)
					end
				end
			end
			table.insert(c,chunk)
		end
	end
	
	return c
end

function love.load()
	chunks = generateChunks()
	chunkmeshes = generateChunkMeshes(chunks)
end

function love.update(dt)
	local mousex, mousey = love.mouse.getPosition()
	mx = mousex - love.graphics.getWidth()/2
	my = mousey - love.graphics.getHeight()/2
	camrot.x = camrot.x + math.rad(my * sensitivity * dt)
	camrot.y = camrot.y + math.rad(mx * sensitivity * dt)
	love.mouse.setPosition(love.graphics.getWidth()/2,love.graphics.getHeight()/2)
	if love.keyboard.isDown('j') then
		camrot.y = camrot.y - dt
		--l3d.rotate(-0.2,cpml.vec3(0,0,1))
		-- camroty = camroty - 0.01
	end
	if love.keyboard.isDown('l') then
		camrot.y = camrot.y + dt
		--l3d.rotate(0.2,cpml.vec3(0,0,1))
		-- camroty = camroty + 0.01
	end
	if love.keyboard.isDown('e') then
		camy = camy + dt
		-- camlooky = camlooky+0.01
		--view:translate(view,cpml.vec3(camx,camy,camz))
	end
	if love.keyboard.isDown('q') then
		camy = camy - dt
		-- camlooky = camlooky-0.01
		--view:translate(view,cpml.vec3(camx,camy,camz))
	end
	if love.keyboard.isDown('w') then
		camx = camx-math.sin(camrot.y)*dt
		camy = camy-math.cos(-camrot.y)*dt
		camz = camz-math.cos(camrot.x)*dt
	end
	if love.keyboard.isDown('s') then
		camx = camx+math.sin(camrot.y)*dt
		camy = camy+math.cos(-camrot.y)*dt
		camz = camz+math.cos(camrot.x)*dt
	end
	if love.keyboard.isDown('d') then
		camx = camx-math.cos(camrot.y)*dt
		camy = camy-math.sin(-camrot.y)*dt
		camz = camz-math.sin(camrot.z)*dt
	end
	if love.keyboard.isDown('a') then
		camx = camx+math.cos(camrot.y)*dt
		camy = camy+math.sin(-camrot.y)*dt
		camz = camz+math.sin(camrot.z)*dt
	end
end

function love.draw()

end
